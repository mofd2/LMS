import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;



public class ReadFile {
    public static void main(String[] args) {
        String data = null;
        try {
            File project = new File("student-data.txt");
            Scanner sc = new Scanner(project);
            while (sc.hasNextLine()) {
                data = sc.nextLine();
            }
            sc.close();

        } catch (FileNotFoundException e) {
            System.out.println("An error occurredREAD TXT.");
        }
        data = data.replace("#", ",");
        data = data.replace("$", "\n");
//        System.out.println(data);

//        Split data into a list of entries
//        Note that the first entry is actually the CSV header
        String[] lines = data.split("\n");
        String output = "";

//        Loop over the items in list
//        Add prefix to each list. This prefix should be "id," if this is the first line (i.e. CSV header) or a counter value that starts with 1
        for (int i = 0; i < lines.length; i++) {

            if (i == 0) {
                output = output + "id," + lines[i] + "\n";
            } else {
                output = output + Integer.toString(i) + "," + lines[i] + "\n";
            }
        }
            System.out.println(output);

        // Write `output` to `file.csv`
        try {
            FileWriter csvFile = new FileWriter("student.csv");
            int s = 0;
            while (s < output.length()) {
                csvFile.write(output);
            }
            csvFile.close();


        } catch (IOException e) {
            System.out.println("An error occurredWRITING CSV.");
        }
        try {
            File xmlCourses = new File("coursedata.xml");
            Scanner sc = new Scanner(xmlCourses);
            String xdata = null;
            while (sc.hasNextLine()) {
                xdata = sc.nextLine();
            }
            sc.close();
            System.out.println(xdata);
        } catch (FileNotFoundException e) {
            System.out.println("An error occurredXML.");


        }



    }
}


